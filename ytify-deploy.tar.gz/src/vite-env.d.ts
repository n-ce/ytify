/// <reference types="vite/client" />
/// <reference types="vite-plugin-pwa/client" />

declare const Build: string;
declare const Backend: string[];
declare const Locales: string[];
